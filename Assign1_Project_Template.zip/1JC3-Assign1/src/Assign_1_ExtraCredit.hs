{- Assignment 1
 - Name: TODO add full name
 - Date: TODO add of completion
 -}
module Assign_1_ExtraCredit where

-- import Data.Complex -- TODO uncomment me to use built-in Complex type
-- see https://www.stackage.org/haddock/lts-8.24/base-4.9.1.0/Data-Complex.html

macid = "TODO: put your mac id here"
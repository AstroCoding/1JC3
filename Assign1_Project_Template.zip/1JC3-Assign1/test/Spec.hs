import Test.QuickCheck
import qualified Assign_1 as A1
import qualified Assign_1_ExtraCredit as A1E

main :: IO ()
main = putStrLn "Test suite not yet implemented"

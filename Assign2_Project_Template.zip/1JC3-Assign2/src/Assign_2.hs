{- Assignment 2
 - Name: TODO add full name
 - Date: TODO add of completion
 -}
module Assign_2 where

macid :: String
macid = "TODO: put your mac id here"

type GaussianInt = (Integer,Integer)

{- -----------------------------------------------------------------
 - gaussReal
 - -----------------------------------------------------------------
 - Description: TODO add comments on gaussZero here
 -}
gaussReal :: GaussianInt -> Integer
gaussReal (x,y) = error "TODO: implement gaussReal"

{- -----------------------------------------------------------------
 - gaussImag
 - -----------------------------------------------------------------
 - Description: TODO add comments on gaussZero here
 -}
gaussImag :: GaussianInt -> Integer
gaussImag (x,y) = error "TODO: implment gaussImag"


{- -----------------------------------------------------------------
 - gausConj
 - -----------------------------------------------------------------
 - Description: TODO add comments on gausConj here
 -}
gaussConj :: GaussianInt -> GaussianInt
gaussConj g = error "TODO: implement gaussConj"

{- -----------------------------------------------------------------
 - gaussAdd
 - -----------------------------------------------------------------
 - Description: TODO add comments on gaussAdd here
 -}
gaussAdd :: GaussianInt -> GaussianInt -> GaussianInt
gaussAdd g0 g1 = error "TODO: implement gaussAdd"

{- -----------------------------------------------------------------
 - gaussMult
 - -----------------------------------------------------------------
 - Description: TODO add comments on gaussMult here
 -}
gaussMult :: GaussianInt -> GaussianInt -> GaussianInt
gaussMult g0 g1 = error "TODO: implement gaussMult"

{- -----------------------------------------------------------------
 - gaussNorm
 - -----------------------------------------------------------------
 - Description: TODO add comments on gaussNorm here
 -}
gaussNorm :: GaussianInt -> Integer
gaussNorm g = error "TODO: implement gaussNorm"

{- -----------------------------------------------------------------
 - maxGaussNorm
 - -----------------------------------------------------------------
 - Description: TODO add comments on maxGaussNorm here
 -}
maxGaussNorm :: [GaussianInt] -> GaussianInt
maxGaussNorm gs = error "TODO: implment maxGaussNorm"

{- -----------------------------------------------------------------
 - Test Cases
 - -----------------------------------------------------------------
 -
 - -----------------------------------------------------------------
 - - Function:
 - - Test Case Number:
 - - Input:
 - - Expected Output:
 - - Acutal Output:
 - -----------------------------------------------------------------
 - TODO: add test cases
 -}

